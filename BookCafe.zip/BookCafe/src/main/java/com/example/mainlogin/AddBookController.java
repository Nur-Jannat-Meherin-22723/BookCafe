package com.example.mainlogin;

import com.example.mainlogin.database.DatabaseConnection;
import com.example.mainlogin.database.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AddBookController implements Initializable {
    @FXML
    public Label msgLabel;

    @FXML
    public TextField book_author;
    @FXML
    public TextField book_name;
    @FXML
    public TextField book_genre;
    @FXML
    public TextField book_publisher;
    @FXML
    public TextField book_price;
    @FXML
    public TextField book_availability;
    //public TextField available_buying;
    //public TextField available_reading;
    @FXML
    private Button btnReturn3;
    @FXML
    public Button book_save;

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;


    //click << button of AddBook page to enter Dashboard page
    public void handleBtn12() throws Exception {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn3.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }


    public void save(ActionEvent event) throws IOException {
        ResultSet rs;
        PreparedStatement ps;
        DatabaseConnection connect = new DatabaseConnection();
        try {

            Connection con = connect.getConnection();

            String name = book_name.getText().trim();
            String author = book_author.getText().trim();
            String genre = book_genre.getText().trim();
            String publisher = book_publisher.getText().trim();
            String price = book_price.getText().trim();
            String avaiability = book_availability.getText().trim();

            if (name.isEmpty() || publisher.isEmpty() || genre.isEmpty() || author.isEmpty() || price.isEmpty() || avaiability.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Library Error");
                alert.setHeaderText("Add Book Error!");
                alert.setContentText("Complete all the fields to insert a book to the system.");

                alert.showAndWait();
            } else {

                String sql2 = "insert into newbook(name,author,genre,publisher,price,availability) value (?,?,?,?,?,?)";
                ps = con.prepareStatement(sql2);

                ps.setString(1, book_name.getText().trim());
                ps.setString(2, book_author.getText().trim());
                ps.setString(3, book_genre.getText().trim());
                ps.setString(4, book_publisher.getText().trim());
                ps.setString(5, book_price.getText().trim());
                ps.setString(6, book_availability.getText().trim());

                ps.execute();

                msgLabel.setText("Book added to the system");

            }

        } catch (Exception e) {
            System.out.println("error" + e);
        }
    }

    public void cancel(ActionEvent event) {
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO

    }
}








//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //Raisa Islam
   /*@FXML
    void addBook(ActionEvent event) throws IOException {
        ResultSet rs;
        PreparedStatement ps;
        Connectivity connect = new Connectivity();
        try {

            Connection con = connect.ConnectDb();

            String title = btitleTxt.getText().trim();
            String bcode = bcodeTxt.getText().trim();
            String price = bpriceTxt.getText().trim();
            String category = bcategoryTxt.getText().trim();
            String publisher = bpublisherTxt.getText().trim();
            String edition = beditionTxt.getText().trim();

            if (category.isEmpty() || publisher.isEmpty() || title.isEmpty() || bcode.isEmpty() || price.isEmpty() || edition.isEmpty()) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Library Error");
                alert.setHeaderText("Add Book Error!");
                alert.setContentText("Complete all the fields to insert a book to the system.");

                alert.showAndWait();
            } else {

                String sql2 = "insert into books (booktitle,bookid,price,categ,publishers,edition) value (?,?,?,?,?,?)";
                ps = con.prepareStatement(sql2);

                ps.setString(1, btitleTxt.getText().trim());
                ps.setString(2, bcodeTxt.getText().trim());
                ps.setString(3, bpriceTxt.getText().trim());
                ps.setString(4, bcategoryTxt.getText().trim());
                ps.setString(5, bpublisherTxt.getText().trim());
                ps.setString(6, beditionTxt.getText().trim());

                ps.execute();

                msgLabel.setText("Book added to the system");

            }

        } catch (Exception e) {
            System.out.println("error" + e);
        }
    }

    @FXML
    public void backtoDashboard(ActionEvent event) throws IOException {
        Parent view3 = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
        Scene scene3 = new Scene(view3);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene3);
        window.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO


    }

    */
