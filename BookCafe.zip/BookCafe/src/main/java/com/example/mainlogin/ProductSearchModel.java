package com.example.mainlogin;


public class ProductSearchModel {
    /*
    Integer productID;
    String brand, modelNumber;
    Integer modelYear;
    String productName, description;

     */
    Integer productID;
    String name, author,genre,publisher,price,availability;
    //Integer modelYear;
    //String productName, description;


    public ProductSearchModel(Integer productID, String name, String author, String genre, String publisher,String price, String availability){
        this.productID = productID;
        this.name = name;
        this.author = author;
        //this.modelYear = modelYear;
        this.genre = genre;
        this.publisher = publisher;
        this.price = price;
        this.availability = availability;
    }

    public Integer getProductID() {
        return productID;
    }

    public String getBrand() {
        return name;
    }

    public String getModelNumber() {
        return author;
    }

    /*public Integer getModelYear() {
        return modelYear;
    }*/

    public String getProductName() {
        return genre;
    }

    public String getDescription() {
        return publisher;
    }

    public String getPrice() {
        return price;
    }

    public String getAvailability() {
        return availability;
    }

    public void setProductID(Integer productID) {
        this.productID = productID;
    }

    public void setBrand(String name) {
        this.name = name;
    }

    public void setModelNumber(String author) {
        this.author = author;
    }

    /*public void setModelYear(Integer modelYear) {
        this.modelYear = modelYear;
    }*/

    public void setProductName(String genre) {
        this.genre = genre;
    }

    public void setDescription(String publisher) {
        this.publisher = publisher;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }
}
