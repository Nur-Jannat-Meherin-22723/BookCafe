package com.example.mainlogin;


import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProductSearchController implements Initializable {
    @FXML
    private TableView<ProductSearchModel> productTableView;
    @FXML
    private TableColumn<ProductSearchModel, Integer> productIDTableColumn;
    @FXML
    private TableColumn<ProductSearchModel, String> brandTableColumn;
    @FXML
    private TableColumn<ProductSearchModel, String> modelNumberTableColumn;
   // @FXML
    //private TableColumn<ProductSearchModel, Integer> modelYearTableColumn;
    @FXML
    private TableColumn<ProductSearchModel, String> productNameTableColumn;
    @FXML
    private TableColumn<ProductSearchModel, String> descriptionTableColumn;

    @FXML
    private TableColumn<ProductSearchModel, String> priceTableColumn;

    @FXML
    private TableColumn<ProductSearchModel, String> availabilityTableColumn;


    @FXML
    private TextField keywordTextField;

    ObservableList<ProductSearchModel> productSearchModelObservableList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resource){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();
        //String productViewQuery = "SELECT id, name, author, genre, publisher, price, availability FROM newbook";
        String productViewQuery = "SELECT * FROM newbook";
        //String productInsertQuery = "Insert INTO product";

        try{
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(productViewQuery);

            while (queryOutput.next()){
                Integer queryProductID = queryOutput.getInt("id");
                String queryBrand = queryOutput.getString("name");
                String queryModelNumber = queryOutput.getString("author");
                //Integer queryModelYear = queryOutput.getInt("ModelYear");
                String queryProductName = queryOutput.getString("genre");
                String queryDescription = queryOutput.getString("publisher");
                String queryPrice = queryOutput.getString("price");
                String queryAvailability = queryOutput.getString("availability");
                productSearchModelObservableList.add(new ProductSearchModel(queryProductID, queryBrand, queryModelNumber, queryProductName, queryDescription, queryPrice, queryAvailability));

                productIDTableColumn.setCellValueFactory(new PropertyValueFactory<>("productID"));
                brandTableColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
                modelNumberTableColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
                //modelYearTableColumn.setCellValueFactory(new PropertyValueFactory<>("modelYear"));
                productNameTableColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
                descriptionTableColumn.setCellValueFactory(new PropertyValueFactory<>("publisher"));
                priceTableColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
                availabilityTableColumn.setCellValueFactory(new PropertyValueFactory<>("availability"));

                productTableView.setItems(productSearchModelObservableList);
            }
            FilteredList<ProductSearchModel> filteredData = new FilteredList<>(productSearchModelObservableList, b->true);
            keywordTextField.textProperty().addListener((observable, oldValue, newValue)-> {
                filteredData.setPredicate(productSearchModel -> {
                    if(newValue.isEmpty() || newValue.isBlank() || newValue == null){
                        return true;
                    }
                    String searchKeyword = newValue.toLowerCase();
                    //--------------------------------------------------------------------------------------
                    if(productSearchModel.getProductID().toString().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getProductID().toString().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getBrand().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getBrand().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getModelNumber().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getModelNumber().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getBrand().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getBrand().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    else if(productSearchModel.getProductName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getProductName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    /*else if(productSearchModel.getModelYear().toString().indexOf(searchKeyword) > -1){
                        return true;
                    }*/
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getDescription().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getDescription().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    else {
                        return false;
                    }
                });
            });

            SortedList<ProductSearchModel> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(productTableView.comparatorProperty());
            productTableView.setItems(sortedData);

        } catch (SQLException e){
            Logger.getLogger(ProductSearchController.class.getName()).log(Level.SEVERE, null, e);
            e.printStackTrace();
        }

    }

    public void handleButton(ActionEvent event) {
    }

    public void handleBtn13(ActionEvent event) {
    }
}
