package com.example.mainlogin;

import com.example.mainlogin.database.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegistrationController implements Initializable {
    @FXML
    public TextField ename;
    @FXML
    public TextField ephone;
    @FXML
    public TextField eaddress;
    @FXML
    public TextField edesignation;
    @FXML
    public PasswordField epassword;
    @FXML
    private TableView<Employee> table;
    @FXML
    private TableColumn<Employee, String> teid;
    @FXML
    private TableColumn<Employee, String> tename;

    @FXML
    private TableColumn<Employee, String> tephone;

    @FXML
    private TableColumn<Employee, String> teaddress;
    @FXML
    private TableColumn<Employee, String> tedesignation;



    @FXML
    public Button eupdate;
    @FXML
    public Button edelete;
    @FXML
    public Button esave;

    @FXML
    private Button btnReturn8;



    //click << button of Registration page to enter Login page
    public void handleBtn15() throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Stage window = (Stage) btnReturn8.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;

    public void table()
    {
        Connect();
        ObservableList<Employee> students = FXCollections.observableArrayList();
        try
        {
            pst = con.prepareStatement("select id,name,mobile,address,designation from registation");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next())
                {
                    Employee st = new Employee();
                    st.setId(rs.getString("id"));
                    st.setName(rs.getString("name"));
                    st.setMobile(rs.getString("mobile"));
                    st.setAddress(rs.getString("address"));
                    st.setDesignation(rs.getString("designation"));
                    students.add(st);
                }
            }
            table.setItems(students);
            teid.setCellValueFactory(f -> f.getValue().idProperty());
            tename.setCellValueFactory(f -> f.getValue().nameProperty());
            tephone.setCellValueFactory(f -> f.getValue().mobileProperty());
            teaddress.setCellValueFactory(f -> f.getValue().addressProperty());
            tedesignation.setCellValueFactory(f -> f.getValue().designationProperty());






        }

        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        table.setRowFactory( tv -> {
            TableRow<Employee> myRow = new TableRow<>();
            myRow.setOnMouseClicked (event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty()))
                {
                    myIndex =  table.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));
                    ename.setText(table.getItems().get(myIndex).getName());
                    ephone.setText(table.getItems().get(myIndex).getMobile());
                    eaddress.setText(table.getItems().get(myIndex).getAddress());
                    edesignation.setText(table.getItems().get(myIndex).getDesignation());
                    epassword.setText(table.getItems().get(myIndex).getPassword());




                }
            });
            return myRow;
        });


    }
    public void save(ActionEvent event) {
        //RegistrationConnection rc = new RegistrationConnection(ename.getText(), ephone.getText(), eaddress.getText(), edesignation.getText(), epassword.getText());
        //Add();
        String stname,mobile,address,designation,password;
        stname = ename.getText();
        mobile = ephone.getText();
        address = eaddress.getText();
        designation=edesignation.getText();
        password=epassword.getText();
        try
        {
            pst = con.prepareStatement("insert into registation(name,mobile,address,designation,password)values(?,?,?,?,?)");
            pst.setString(1, stname);
            pst.setString(2, mobile);
            pst.setString(3, address);
            pst.setString(4, designation);
            pst.setString(5, password);
            pst.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Student Registation");

            alert.setHeaderText("Student Registation");
            alert.setContentText("Record Addedddd!");

            alert.showAndWait();

            table();

            ename.setText("");
            ephone.setText("");
            eaddress.setText("");
            edesignation.setText("");
            epassword.setText("");
            ename.requestFocus();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }



    /*void Add() {

        String stname,mobile,address,designation,password;
        stname = ename.getText();
        mobile = ephone.getText();
        address = eaddress.getText();
        designation=eaddress.getText();
        password=epassword.getText();
        try
        {
            pst = con.prepareStatement("insert into registation(name,mobile,address, designation, password)values(?,?,?,?,?)");
            pst.setString(1, stname);
            pst.setString(2, mobile);
            pst.setString(3, address);
            pst.setString(4, designation);
            pst.setString(5, password);
            pst.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Student Registation");

            alert.setHeaderText("Student Registation");
            alert.setContentText("Record Addedddd!");

            alert.showAndWait();

            table();

            ename.setText("");
            ephone.setText("");
            eaddress.setText("");
            edesignation.setText("");
            epassword.setText("");
            ename.requestFocus();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/

    public void delete(ActionEvent event) {
        myIndex = table.getSelectionModel().getSelectedIndex();
        id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));


        try
        {
            pst = con.prepareStatement("delete from registation where id = ? ");
            pst.setInt(1, id);
            pst.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Student Registationn");

            alert.setHeaderText("Student Registation");
            alert.setContentText("Deletedd!");

            alert.showAndWait();
            table();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }




    public void update(ActionEvent event) {
        String stname,mobile,address, designation, password;

        myIndex = table.getSelectionModel().getSelectedIndex();
        id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));

        stname = ename.getText();
        mobile = ephone.getText();
        address = eaddress.getText();
        designation=edesignation.getText();
        password=epassword.getText();
        try
        {
            pst = con.prepareStatement("update registation set name = ?,mobile = ? ,address = ?,designation = ?,password = ? where id = ? ");
            pst.setString(1, stname);
            pst.setString(2, mobile);
            pst.setString(3, address);
            pst.setString(4, designation);
            pst.setString(5, password);
            pst.setInt(6, id);
            pst.executeUpdate();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Student Registationn");

            alert.setHeaderText("Student Registation");
            alert.setContentText("Updateddd!");

            alert.showAndWait();
            table();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet","root","the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Connect();
        table();

    }
}
