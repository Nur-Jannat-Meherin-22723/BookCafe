package com.example.mainlogin;


import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class IssueBookController implements Initializable {

    public Pane pn_bb;
    public Pane pn_lb;
    public Pane pn_rb;
    public Pane pn_t;
    public Pane pn_lt;
    public JFXButton rb;
    public JFXButton trans;
    public JFXButton lb;
    public JFXButton bb;
    public JFXButton ltrans;
    @FXML
    private Button btnReturn6;

    //click << button of IssueBook page to enter Dashboard page
    public void handleBtn4() throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn6.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }


    public void handleButton(ActionEvent event) {
        if(event.getSource() == bb){
            pn_bb.toFront();
        }
        else if(event.getSource() == lb){
            pn_lb.toFront();
        }
        else if(event.getSource() == trans){
            pn_t.toFront();
        }
        else if(event.getSource() == ltrans){
            pn_lt.toFront();
        }
        else if(event.getSource() == rb){
            pn_rb.toFront();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
