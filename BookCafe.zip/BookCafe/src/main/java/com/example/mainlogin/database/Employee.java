package com.example.mainlogin.database;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Employee {

    private final StringProperty id;
    private final StringProperty name;
    private final StringProperty mobile;
    private final StringProperty  address;
    private final StringProperty designation;
    private final StringProperty password;

    public Employee()
    {
        id = new SimpleStringProperty(this, "id");
        name = new SimpleStringProperty(this, "name");
        mobile = new SimpleStringProperty(this, "mobile");
        address = new SimpleStringProperty(this, "address");
        designation=new SimpleStringProperty(this,"designation");
        password=new SimpleStringProperty(this,"password");
    }

    public StringProperty idProperty() { return id; }
    public String getId() { return id.get(); }
    public void setId(String newId) { id.set(newId); }

    public StringProperty nameProperty() { return name; }
    public String getName() { return name.get(); }
    public void setName(String newName) { name.set(newName); }

    public StringProperty mobileProperty() { return mobile; }
    public String getMobile() { return mobile.get(); }
    public void setMobile(String newMobile) { mobile.set(newMobile); }

    public StringProperty addressProperty() { return address; }
    public String getAddress() { return address.get(); }
    public void setAddress(String newName) { address.set(newName); }


    public StringProperty designationProperty() { return designation; }
    public String getDesignation() { return designation.get(); }
    public void setDesignation(String newDesignation) { designation.set(newDesignation); }

    public StringProperty passwordProperty() { return password; }
    public String getPassword() { return password.get(); }
    public void setPassword(String newPassword) { password.set(newPassword); }
}
